import './App.css';
import Header from './component/Header';
import {BrowserRouter, Switch, Route} from "react-router-dom";
import AddEdit from './component/AddEdit';
import ListRecord from './component/ListRecord';
import { ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import View from './component/View';
import About from './component/About';
import Error from './component/Error';

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      <ToastContainer position="top-right" />
      <Header/>
      <Switch>
        <Route exact path= "/" component={ListRecord}/>
        <Route exact path= "/add" component={AddEdit}/>
        <Route exact path= "/update/:id" component={AddEdit}/>
        <Route exact path= "/view/:id" component={View}/>
        <Route exact path= "/about" component={About}/>
        <Route path="*"component={Error}/>
      </Switch>
    </div>
    </BrowserRouter>
  );
}

export default App;
