import React, {useState, useEffect} from 'react';
import firebaseDb from '../firebase';
import { Link } from 'react-router-dom';
import {toast} from "react-toastify";
import {useHistory} from "react-router-dom";

const ListRecord = () => {
const [data, setData] = useState({});
const history = useHistory();


useEffect (() => {
    firebaseDb.child("contacts").on("value", (snapshot) => {
        if(snapshot.val() !== null) {
            setData ({...snapshot.val(),
            });
        } else {
            setData({});
        }
    });
},[]);

    const onDelete = (id) => {
        if(window.confirm("Are you sure you want to delete this information?")) {
            firebaseDb.child(`/contacts/${id}`).remove((err) => {
                if(err) {
                    toast.error(err)
                } else {
                    toast.success("Contact Deleted Successfully");
                }
            });
        
            setTimeout(() => history.push("/"), 500);
        }
    };

    return (
        <div className="container-fluid mt-5">
            <div className="row">
                <div className="col-lg-12">
                    <div className="jumbotron">
                        <h2 className="display-2">Contact Management Web System</h2>
                    </div>
                    <table className="table table-bordered table-striped">
                        <thead className="thead-dark">
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Contact Number</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Object.keys(data).map((id, index) => {
                                return (
                                   <tr key={id}>
                                       <th scope="row">{index+1}</th>
                                       <td>{data[id].name}</td>
                                       <td>{data[id].email}</td>
                                       <td>{data[id].contactnumber}</td>
                                       <td>
                                           <Link to={`/update/${id}`}>
                                               <a className="btn text-primary">
                                                    <i className="fas fa-pencil-alt"/>
                                               </a>
                                           </Link>
                                           <Link>
                                               <a className="btn text-danger" 
                                               onClick={() => onDelete(id)}
                                               >
                                                    <i className="fas fa-trash-alt"/>
                                                </a>
                                           </Link>
                                           <Link to={`/view/${id}`}>
                                               <a className="btn text-info">
                                                    <i className="fas fa-eye"></i>
                                                </a>
                                           </Link>
                                       </td>
                                   </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default ListRecord;
