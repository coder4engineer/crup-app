import React from 'react';

function About() {
    return (
        <div className="container mt-5">
            <div className="jumbotron">
                <p className="lead">A Create-Read-Update-Delete App System on React Flatform</p>
            </div>
            
        </div>
    )
}

export default About
