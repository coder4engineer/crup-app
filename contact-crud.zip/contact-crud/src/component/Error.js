import React from 'react';

function Error() {
    return (
        <div className="container mt-5">
            <div className="jumbotron jumbotron-fluid">
            <div className="container">
                <h1 className="display-4">No Such Page Exist - Error 404</h1>
            </div>
            </div>
        </div>
    )
}

export default Error
