import React, {useState, useEffect} from 'react'
import firebaseDb from '../firebase';
import {useHistory, useParams, Link} from "react-router-dom";
import { toast } from 'react-toastify';
import { isEmpty } from 'lodash';

const AddEdit = () => {
    const values = {
        name: "",
        email: "",
        contactnumber: ""
    };
    const [data, setData] = useState({});
    const [initialState, setState] = useState(values);
    const {name, email, contactnumber} = initialState;
    const history = useHistory();

    let currentId = useParams ();
    const {id} = currentId;

    useEffect (() => {
    firebaseDb.child("contacts").on("value", (snapshot) => {
        if(snapshot.val() !== null) {
            setData ({...snapshot.val(),
            });
        } else {
            setData({});
        }
    });
    },[id]);
    useEffect (() => {
        if(isEmpty(id)) {
            setState({...values});
        } else {
            setState({...data[id]});
        }
    }, [id, data]);

    const handleInputChange = (e) => {
        const {name, value} = e.target;
        setState({
            ...initialState,
            [name]: value
        });
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        if(isEmpty(id)) {
            firebaseDb.child("contacts").push(initialState, (err) => {
                    if (err) {
                        console.log(err);
                    }else {
                        toast.success("Contact Added Successfully");
                    }
            });
            }else {
              firebaseDb.child(`/contacts/${id}`).set(initialState, (err) => {
                    if (err) {
                        console.log(err);
                    } else {
                        toast.success("Contact Updated Successfully");
                    }
            });   
        }
            setTimeout(() => history.push("/"), 500);
    };

    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label className="bmd-label-floating">Name</label>
                            <input
                                type="text"
                                className="form-control"
                                value={name}
                                name="name"  
                                onChange={handleInputChange}  
                            />
                        </div>
                        <div className="form-group">
                            <label className="bmd-label-floating">Email</label>
                            <input
                                type="email"
                                className="form-control"
                                value={email}
                                name="email"  
                                onChange={handleInputChange}  
                            />
                        </div>
                        <div className="form-group">
                            <label className="bmd-label-floating">Contact Number</label>
                            <input
                                type="number"
                                className="form-control"
                                value={contactnumber}
                                name="contactnumber"  
                                onChange={handleInputChange}  
                            />
                        </div>
                        <button type="submit" className="btn btn-success btn-raised">
                            Save
                        </button>
                        <Link to="/">
                                    <a className="btn btn-info">Cancel</a>
                        </Link>
                    </form>
                </div>
            </div>
            </div>
    )
}

export default AddEdit
