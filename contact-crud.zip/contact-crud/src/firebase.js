import firebase from "firebase/compat/app";
import "firebase/compat/database";

const firebaseConfig = {
    apiKey: "AIzaSyBu_E5rXKhvolRNeqNziQRkgoe70OZOGgQ",
    authDomain: "contact-list-firebase.firebaseapp.com",
    databaseURL: "https://contact-list-firebase-default-rtdb.firebaseio.com",
    projectId: "contact-list-firebase",
    storageBucket: "contact-list-firebase.appspot.com",
    messagingSenderId: "744658248647",
    appId: "1:744658248647:web:a97527a23af617ddeeefe2"
  };
  
  // Initialize Firebase
  const fireDb = firebase.initializeApp(firebaseConfig);
  export default fireDb.database().ref();
